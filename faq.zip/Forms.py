from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators

class CreateEnquiryForm(Form):
    firstName = StringField('First Name', [validators.Length(min=1,max=150), validators.DataRequired()])
    lastName = StringField('Last Name', [validators.Length(min=1,max=150), validators.DataRequired()])
    email = StringField('Email', [validators.Length(min=1,max=150), validators.DataRequired()])
    enquiry = StringField('Enquiry', [validators.Length(min=1,max=150), validators.DataRequired()])
    remarks = TextAreaField('Remarks', [validators.Optional()])

class Enquiry:
    countID = 0

    def __init__(self, firstName, lastName, email, enquiry, remarks):
        Enquiry.countID += 1
        self.__enquiryID = Enquiry.countID
        self.__firstName = firstName
        self.__lastName = lastName
        self.__email = email
        self.__enquiry = enquiry
        self.__remarks = remarks

    def get_enquiryID(self):
        return self.__enquiryID

    def get_firstName(self):
        return self.__firstName

    def get_lastName(self):
        return self.__lastName

    def get_email(self):
        return self.__email

    def get_enquiry(self):
        return self.__enquiry

    def get_remarks(self):
        return self.__remarks

    def set_enquiryID(self, enquiryID):
        self.__enquiryID = enquiryID

    def set_firstName(self, firstName):
        self.__firstName = firstName

    def set_lastName(self, lastName):
        self.__lastName = lastName

    def set_email(self, email):
        self.__email = email

    def set_enquiry(self, enquiry):
        self.__enquiry = enquiry

    def set_remarks(self, remarks):
        self.__remarks = remarks




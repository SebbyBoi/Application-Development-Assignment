from flask import Flask, render_template, request, redirect, url_for
from Forms import CreateEnquiryForm
import shelve, Enquiry

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/storeLocate')
def storeLocate():
    return render_template('storeLocate.html')

@app.route('/feedback')
def feedback():
    return render_template('feedback.html')

@app.route('/payment')
def payment():
    return render_template('payment.html')

@app.route('/createEnquiry', methods=['GET', 'POST'])
def createEnquiry():
    createEnquiryForm = CreateEnquiryForm(request.form)
    if request.method == 'POST' and createEnquiryForm.validate():
        enquiryDict = {}
        db = shelve.open('storage.db', 'c')

        try:
            enquiryDict = db['Enquiry']
        except:
            print("Error in retrieving enquiries from storage.db.")

        enquiry = Enquiry.Enquiry(createEnquiryForm.firstName.data,
createEnquiryForm.lastName.data, createEnquiryForm.email.data,
createEnquiryForm.enquiry.data, createEnquiryForm.remarks.data)

        enquiryDict[enquiry.get_enquiryID()] = enquiry
        db['Enquiry'] = enquiryDict

        db.close()

        return redirect(url_for('retrieveEnquiries'))
    return render_template('createEnquiry.html', form=createEnquiryForm)

@app.route('/retrieveEnquiries.html')
def retrieveEnquiries():
    enquiriesDict= {}
    db = shelve.open('storage.db', 'r')
    enquiriesDict= db['Enquiry']
    db.close()

    enquiryList = []
    for key in enquiriesDict:
        enquiry = enquiriesDict.get(key)
        enquiryList.append(enquiry)

    return render_template('retrieveEnquiries.html', enquiryList=enquiryList, count=len(enquiryList))

@app.route('/updateEnquiry/<int:id>/', methods=['GET', 'POST'])
def updateEnquiry(id):
    updateEnquiryForm = CreateEnquiryForm(request.form)
    if request.method == 'POST' and updateEnquiryForm.validate():
        enquiryDict = {}
        db = shelve.open('storage.db', 'w')
        enquiryDict = db['Enquiry']

        enquiry = enquiryDict.get(id)
        enquiry.set_firstName(updateEnquiryForm.firstName.data)
        enquiry.set_lastName(updateEnquiryForm.lastName.data)
        enquiry.set_email(updateEnquiryForm.email.data)
        enquiry.set_enquiry(updateEnquiryForm.enquiry.data)
        enquiry.set_remarks(updateEnquiryForm.remarks.data)

        db['Enquiry'] = enquiryDict
        db.close()

        return redirect(url_for('retrieveEnquiries'))
    else:
        enquiryDict = {}
        db = shelve.open('storage.db', 'r')
        enquiryDict = db['Enquiry']
        db.close()

        enquiry = enquiryDict.get(id)
        updateEnquiryForm.firstName.data = enquiry.get_firstName()
        updateEnquiryForm.lastName.data = enquiry.get_lastName()
        updateEnquiryForm.email.data = enquiry.get_email()
        updateEnquiryForm.enquiry.data = enquiry.get_enquiry()
        updateEnquiryForm.remarks.data = enquiry.get_remarks()
        return render_template('updateEnquiry.html', form=updateEnquiryForm)

@app.route('/deleteEnquiry/<int:id>', methods=['POST'])
def deleteEnquiry(id):
    enquiryDict = {}
    db = shelve.open('storage.db', 'w')
    enquiryDict = db['Enquiry']

    enquiryDict.pop(id)

    db['Enquiry'] = enquiryDict
    db.close()

    return redirect(url_for('retrieveEnquiries'))

if __name__=='__main__':
    app.run(debug=True)


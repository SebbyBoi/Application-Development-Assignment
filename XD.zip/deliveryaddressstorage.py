import shelve
class eachdelivery:
    def __init__(self,id,firstname,lastname,email,phone,street,postalcode,unitno):
        self.__id=id
        self.__firstname=firstname
        self.__lastname=lastname
        self.__email=email
        self.__phone=phone
        self.__street=street
        self.__postalcode=postalcode
        self.__unitno=unitno
    def get_id(self):
        return self.__id
    def get_firstname(self):
        return self.__firstname
    def get_lastname(self):
        return self.__lastname
    def get_email(self):
        return self.__email
    def get_phone(self):
        return self.__phone
    def get_street(self):
        return self.__street
    def get_postalcode(self):
        return self.__postalcode
    def get_unitno(self):
        return self.__unitno
deliverydb=shelve.open("deliverydb")
def storeaddress(id,firstname,lastname,email,phone,street,postalcode,unitno):
    object=eachdelivery(id,firstname,lastname,email,phone,street,postalcode,unitno)
    deliverydb[id]=object


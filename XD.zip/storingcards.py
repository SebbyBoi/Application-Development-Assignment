import shelve
class card:
    def __init__(self,id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
        self._cardname=cardname
        self.__cardnumber=cardnumber
        self.__monthdate=monthdate
        self.__yeardate=yeardate
        self.__cvv=cvv
        self.__street=street
        self.__postalcode=postalcode
        self.__unitcode=unitcode
        self.__id=id
    def get_id(self):
        return self.__id
    def get_cardname(self):
        return self.__cardname
    def get_cardnumber(self):
        return self.__cardnumber
    def get_monthdate(self):
        return self.__monthdate
    def get_yeardate(self):
        return self.__yeardate
    def get_cvv(self):
        return self.__cvv
    def get_street(self):
        return self.__street
    def get_postalcode(self):
        return self.__postalcode
    def get_unitcode(self):
        return self.__unitcode
class visacard(card):
    def __init__(self,id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
        super().__init__(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
class mastercard(card):
    def __init__(self,id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
        super().__init__(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
class Amex(card):
    def __init__(self,id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
        super().__init__(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
class discover(card):
    def __init__(self,id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
        super().__init__(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)

cardstorage=shelve.open("cardstoragedb")
def storevisacard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
    object=visacard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
    cardstorage[id]=object
def storemastercard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
    object=mastercard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
    cardstorage[id]=object
def storeamexcard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
    object=Amex(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
    cardstorage[id]=object
def storediscovercard(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode):
    object=discover(id,cardname,cardnumber,monthdate,yeardate,cvv,street,postalcode,unitcode)
    cardstorage[id]=object



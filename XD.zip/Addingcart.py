import shelve
class Addingcart:
    countorderid=0
    def __init__(self,id,productid,name,image,size,quantity,price,status):
        Addingcart.countorderid+=1
        self.__id=id
        self.__productid=productid
        self.__name=name
        self.__image=image
        self.__size=size
        self.__quantity=quantity
        self.__price=price
        self.__status=status
    def get_id(self):
        return self.__id
    def get_productid(self):
        return self.__productid
    def get_name(self):
        return self.__name
    def get_image(self):
        return self.__image
    def get_size(self):
        return self.__size
    def get_quantity(self):
        return self.__quantity
    def get_price(self):
        return self.__price
    def get_status(self):
        return self.__status
    def set_status(self,status):
        self.__status=status
    def set_quantity(self,quantity):
        self.__quantity =self.__quantity+quantity
        print(quantity)
personalcart=shelve.open("cart")
def storeinfo(id,productid,name,image,size,quantity,price,status):
    object1=Addingcart(id,productid,name,image,size,quantity,price,status)
    print(Addingcart.countorderid)
    personalcart[str(Addingcart.countorderid)]=object1



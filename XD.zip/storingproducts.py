import shelve
import uuid

class product:
    def __init__(self,name,size,quantity,id,image,price):
        self.__id=id
        self.__name=name
        self.__size=size
        self.__quantity=quantity
        self.__image=image
        self.__price=price
    def get_id(self):
        return self.__id
    def get_name(self):
        return self.__name
    def get_size(self):
        return self.__size
    def get_quantity(self):
        return self.__quantity
    def get_image(self):
        return self.__image
    def get_price(self):
        return self.__price
products=shelve.open("products")
def createproduct():
    id="1"
    name="woman t shirt"
    size="M"
    quantity=1
    price=120
    image='Product1Img1.jpeg'

    object1=product(name,size,quantity,id,image,price)
    object2=product("Colourful Shirt","S",1,"2","product2Img2.jpeg",100)
    products[id]=object1
    products["2"]=object2

createproduct()

def get_product(productid):
    slist=list(products.keys())
    for x in slist:
        if x==productid:
            return products[x]
print(get_product("1"))

from flask import *
from flask_mail import Mail,Message
#This is for Login & Password (Lee Chit Boon)
from persistence import *
from storingproducts import *
from Addingcart import *
from deliveryaddressstorage import *
from storingcards import *
from confirmorders import *
import functools
import shelve
import datetime

import uuid
#Ends here

app = Flask(__name__)
app=Flask(__name__)
app.config['MAIL_SERVER']="smtp.gmail.com"
app.config['MAIL_PORT']=465
app.config['MAIL_USERNAME']="xxinyyingg@gmail.com"
app.config['MAIL_PASSWORD']="T0205517h"
app.config['MAIL_DEFAULT_SENDER']=("XYSHOP","xxinyyingg@gmail.com")
app.config["MAIL_USE_TLS"]=False
app.config["MAIL_USE_SSL"]=True
mail=Mail(app)
app.config.from_mapping(
    SECRET_KEY="alamak"
)

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if session['id'] is None:
            return redirect(url_for('loginPage'))
        return view(**kwargs)
    return wrapped_view


@app.route('/', methods=("GET","POST"))
def homes():


    return render_template('home.html')



def retrieveorders():
    amount=0
    uniquecart=shelve.open('cart')
    for y in uniquecart:
        if uniquecart[y].get_id()==session['id']:
            amount=amount+1

    return amount
@app.route('/loginPage', methods=("GET","POST"))
def loginPage():
    if request.method=="POST":
        username=request.form["username"]
        password=request.form["password"]
        error=None
        if not username:
            error="Username is required"
        elif not password:
            error="Password is required"
        else:
            user=get_user(username,password)
            if user is None:
                error="Wrong username and password"
            else:
                session["id"]=user.get_id()
                session["user_name"]=user.get_username()
                session['numberoforders']=retrieveorders()


                return redirect(url_for("homes"))
            flash(error)
    return render_template('loginPage.html')
@app.route('/afterlogin')
def afterlogin():
    return render_template("afterlogin.html")
@app.route('/signupPage', methods=("GET","POST"))
def signupPage():
     if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        error = None
        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        else:
            create_user(username, password)
            users = shelve.open('user',"r")
            for x in users:
                print(x)

            return redirect(url_for('loginPage'))
        flash(error)
     return render_template('signupPage.html')

@app.route('/<productid>')
def product1(productid):

    product=get_product(productid)
    name=product.get_name()
    image=product.get_image()
    print(image)
    size=product.get_size()
    id=product.get_id()
    quantity=product.get_quantity()
    price=product.get_price()



    return render_template('product1.html',id=id,name=name,image=image,size=size,quantity=quantity,price=price)
@app.route('/<productid>/addingcart')
def addingcart(productid):
    if session['id']:
        datainfo=shelve.open("products","r")
        for x in datainfo:
            if x==productid:
                id=session["id"]
                storeid=datainfo[x].get_id()
                name=datainfo[x].get_name()
                image=datainfo[x].get_image()
                size=datainfo[x].get_size()
                quantity=datainfo[x].get_quantity()
                price=datainfo[x].get_price()
                status="False"
                storeinfo(id,storeid,name,image,size,quantity,price,status)
                retrieveorders()
                session['numberoforders']=retrieveorders()
        return redirect(url_for("product1",productid = productid))
    else:
        return redirect(url_for("loginPage"))



@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('homes'))
@app.route('/purchasePage')
def purchasePage():
    return render_template('purchasePage.html')

@app.route('/Purchased')
def Purchased():
    return render_template('Purchased.html')

@app.route('/searchPage')
def searchPage():
    return render_template('searchPage.html')

@app.route('/notificationPage')
def notificationPage():
    return render_template('notificationPage.html')

@app.route('/helpPage')
def helpPage():
    return render_template('helpPage.html')

@app.route('/cartsPage',methods=('GET','POST'))
def cartPage():
    checkboxlist=[]
    displaydb=shelve.open('cart')
    for x in displaydb:
        if session['id']==displaydb[x].get_id():

            checkboxlist.append(x)
    for xy in displaydb:
        print(displaydb[xy].get_status())

    print(checkboxlist)
    if request.method=="POST":
        valueinlist=request.form.getlist('orderingno')
        valuefortotal=request.form['custId']
        print(valueinlist)
        session["total"]=valuefortotal
        return redirect(url_for("deliveryaddress"))



    return render_template('cartsPage.html',displaydb=displaydb,checkboxlist=checkboxlist)
@app.route('/deliveryaddressPage',methods=('GET','POST'))
def deliveryaddress():
    total=session["total"]
    k=total.split(",")
    totalcost=k[0]
    totalitems=k[1]
    firstnames=""
    lastnames=""
    emails=""
    phones=""
    streets=""
    postalcodes=""
    unitnos=""
    delivery=shelve.open("deliverydb")
    for y in delivery:
        if session["id"]==delivery[y].get_id():
            firstnames=delivery[y].get_firstname()
            lastnames=delivery[y].get_lastname()
            emails=delivery[y].get_email()
            phones=delivery[y].get_phone()
            streets=delivery[y].get_street()
            postalcodes=delivery[y].get_postalcode()
            unitnos=delivery[y].get_unitno()


    if request.method=='POST':
        firstname=request.form['Firstname']
        lastname=request.form['Lastname']
        email=request.form['email']
        phone=request.form['telephone']
        street=request.form['buildingname']
        postalcode=request.form['postalcode']
        unit=request.form['unitno']
        id=session["id"]
        storeaddress(id,firstname,lastname,email,phone,street,postalcode,unit)
        return redirect(url_for("paymentPage"))






    return render_template('deliveryaddresspage.html',totalcost=totalcost,totalitems=totalitems,firstnames=firstnames,lastnames=lastnames,emails=emails,phones=phones,streets=streets,postalcodes=postalcodes,unitnos=unitnos)
@app.route('/paymentPage',methods=('GET','POST'))
def paymentPage():
    total=session["total"]
    apple=total.split(",")
    totalcost=apple[0]
    totalitems=apple[1]
    street=""
    postalcode=""
    unitno=""

    address=shelve.open("deliverydb")
    for x in address:
        if session['id']==address[x].get_id():
            street=address[x].get_street()
            postalcode=address[x].get_postalcode()
            unitno=address[x].get_unitno()
    if request.method=='POST':
        cardname=request.form['cardname']
        cardnumber=request.form['cardnumber']
        monthdate=request.form['monthdate']
        yeardate=request.form['yeardate']
        cvv=request.form['cvv']
        streetd=request.form['streetd']
        postalcoded=request.form['postalcoded']
        unitcoded=request.form['unitcoded']
        id=session['id']
        if cardnumber[0].startswith("3"):
            storeamexcard(id,cardname,cardnumber,monthdate,yeardate,cvv,streetd,postalcoded,unitcoded)
        elif cardnumber[0].startswith('4'):
            storevisacard(id,cardname,cardnumber,monthdate,yeardate,cvv,streetd,postalcoded,unitcoded)
        elif cardnumber[0].startswith('5'):
            storemastercard(id,cardname,cardnumber,monthdate,yeardate,cvv,streetd,postalcoded,unitcoded)
        else:
            storediscovercard(id,cardname,cardnumber,monthdate,yeardate,cvv,streetd,postalcoded,unitcoded)
        return redirect(url_for("verificationPage"))


    return render_template('payment.html',totalcost=totalcost,totalitems=totalitems,street=street,postalcode=postalcode,unitno=unitno)


@app.route('/verificationPage',methods=('GET','POST'))
def verificationPage():
            storage=shelve.open('deliverydb')
            for xy in storage:
                if session['id']==storage[xy].get_id():
                    firstname=storage[xy].get_firstname()
                    lastname=storage[xy].get_lastname()
                    email=storage[xy].get_email()
            secretnumber = str(uuid.uuid4())
            secret=secretnumber[0:8]
            number=secretnumber[8:]
            print(secret)

            msg=Message("Confirmation Verification", recipients=[email])

            msg.html="<h2> ThankYou For Shopping with Us, "+firstname+" "+lastname+"</h2><br><h3>This Is Your Verification Code:</h3>"+secret
            mail.send(msg)
            print(secret)

            return render_template('verificationpage.html',number=number,secret=secret)

@app.route('/viewordersPage',methods=('GET','POST'))
def viewordersPage():
    dates=[]
    displaythings=shelve.open("confirmorders")
    for xy in displaythings:
        if session['id']==displaythings[xy].get_id():
            date=displaythings[xy].get_time()
            dates.append(date)
    passingdate=list(dict.fromkeys(dates))
    passingdate.reverse()
    print(passingdate)





    return render_template('vieworders.html',displaythings=displaythings,passingdate=passingdate)
@app.route('/adminPage')
def adminPage():
    alldate=[]
    displaywoo=shelve.open("confirmorders")
    for u in displaywoo:
        dates=displaywoo[u].get_time()
        alldate.append(dates)
    passinginfo=list(dict.fromkeys(alldate))
    passinginfo.reverse()


    return render_template('adminPage.html',displaywoo=displaywoo,passinginfo=passinginfo)
@app.route("/<deleteconfirm>/deleteconfirmorder")
def deleteconfirmorder(deleteconfirm):
    deleteid=deleteconfirm
    bigstorage=shelve.open('confirmorders')
    for ko in bigstorage:
        if ko==deleteid:
            del bigstorage[ko]
            return redirect(url_for("adminPage"))


@app.route('/<confirmorderid>/pendingoffer')
def pendingoffer(confirmorderid):
    orderid=confirmorderid
    print(orderid)
    data=shelve.open('confirmorders')
    for n in data:
        if n==orderid:
            info=data[n]
            info.set_pending("true")
            data[n]=info
            return redirect(url_for("viewordersPage"))

@app.route('/processingPage',methods=('GET','POST'))
def processingpage():
    x=datetime.datetime.now().replace(microsecond=0)
    address=shelve.open('deliverydb')
    openingcart=shelve.open("cart")

    for j in openingcart:
        if session['id']==openingcart[j].get_id():
            if openingcart[j].get_status()=="true":
                id=openingcart[j].get_id()
                productid=openingcart[j].get_productid()
                quantity=openingcart[j].get_quantity()
                size=openingcart[j].get_size()
                image=openingcart[j].get_image()
                price=openingcart[j].get_price()
                name=openingcart[j].get_name()
                time=x

                street=address[id].get_street()
                postalcode=address[id].get_postalcode()
                unitno=address[id].get_unitno()
                firstname=address[id].get_firstname()
                lastname=address[id].get_lastname()
                pending="false"

                confirmorder(id,productid,quantity,size,time,image,price,street,postalcode,unitno,name,firstname,lastname,pending)
                del openingcart[j]
                session['numberoforders']=retrieveorders()
    return redirect(url_for("viewordersPage"))

@app.route('/customer_servicePage')
def cutomer_servicePage():
    return render_template('customer_servicePage.html')

@app.route('/FemaleDress1')
def FemaleDress1():
    return render_template('FemaleDress1.html')

@app.route('/pastPurchases')
def pastPurchases():
    return render_template('pastPurchases.html')

@app.route('/productlocationPage')
def productlocationPage():
    return render_template('productlocationPage.html')

@app.route('/background_process_test',methods=('GET','POST'))
def background_process_test():
    print("test")
    clicked=None
    if request.method == "POST":
          clicked=request.form['data']
          print(clicked)
          updatedb=shelve.open('cart')
          for id in updatedb:
              if id==clicked:
                  data=updatedb[id]
                  data.set_quantity(1)
                  updatedb[id]=data
                  print("ok")

    return "nothing"
@app.route('/background_process_minus',methods=('GET','POST'))
def background_process_minus():
    print("test")
    clicked=None
    if request.method == "POST":
          clicked=request.form['data']
          print(clicked)
          updatedb=shelve.open('cart')
          for id in updatedb:
              if id==clicked:
                  data=updatedb[id]
                  data.set_quantity(-1)
                  updatedb[id]=data
                  print("ok")
    return "nothing"
@app.route('/<id>/deletepage')
def deletepage(id):
        updatedb=shelve.open('cart')
        for xy in updatedb:
            if xy==id:
                  del updatedb[id]
                  session['numberoforders']=retrieveorders()
                  print("ok")
        return redirect(url_for("cartPage"))

@app.route('/select_process_test',methods=('GET','POST'))
def select_process_test():
    print("test")
    clicked=None
    if request.method == "POST":
          clicked=request.form['data']
          status = request.form['status']
          print(clicked)
          updatedb=shelve.open('cart')
          for id in updatedb:
              if id==clicked:
                  data=updatedb[id]
                  data.set_status(status)
                  updatedb[id]=data
                  print("ok")

    return "nothing"
@app.route('/selectall_process_test',methods=('GET','POST'))
def selectall_process_test():
    print("test")
    clicked=None
    if request.method == "POST":
          status = request.form['status']
          updatedb=shelve.open('cart')
          for id in updatedb:
              if session['id']==updatedb[id].get_id():
                  data=updatedb[id]
                  data.set_status(status)
                  updatedb[id]=data
                  print("ok")

    return "nothing"

@app.route('/deselectall_process_test',methods=('GET','POST'))
def deselectall_process_test():
    print("test")
    clicked=None
    if request.method == "POST":
          status = request.form['status']
          updatedb=shelve.open('cart')
          for id in updatedb:
              if session['id']==updatedb[id].get_id():
                  data=updatedb[id]
                  data.set_status(status)
                  updatedb[id]=data
                  print("ok")

    return "nothing"

if __name__=='__main__':
    app.run(debug=True)



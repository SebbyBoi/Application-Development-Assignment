import shelve
class confirmorders:
    createuniqueid=0
    def __init__(self,id,productid,quantity,size,time,image,price,street,postalcode,unitno,name,firstname,lastname,pending):
        confirmorders.createuniqueid+=1
        self.__id=id
        self.__productid=productid
        self.__quantity=quantity
        self.__size=size
        self.__time=time
        self.__image=image
        self.__price=price
        self.__street=street
        self.__postalcode=postalcode
        self.__unitno=unitno
        self.__name=name
        self.__firstname=firstname
        self.__lastname=lastname
        self.__pending=pending
    def get_id(self):
        return self.__id
    def get_productid(self):
        return self.__productid
    def get_quantity(self):
        return self.__quantity
    def get_size(self):
        return self.__size
    def get_time(self):
        return self.__time
    def get_image(self):
        return self.__image
    def get_price(self):
        return self.__price
    def get_street(self):
        return self.__street
    def get_postalcode(self):
        return self.__postalcode
    def get_unitno(self):
        return self.__unitno
    def get_name(self):
        return self.__name
    def get_firstname(self):
        return self.__firstname
    def get_lastname(self):
        return self.__lastname
    def get_pending(self):
        return self.__pending
    def set_pending(self,pending):
        self.__pending=pending
confirmedorder=shelve.open("confirmorders")
def confirmorder(id,productid,quantity,size,time,image,price,street,postalcode,unitno,name,firstname,lastname,pending):
    object=confirmorders(id,productid,quantity,size,time,image,price,street,postalcode,unitno,name,firstname,lastname,pending)
    confirmedorder[str(confirmorders.createuniqueid)]=object



